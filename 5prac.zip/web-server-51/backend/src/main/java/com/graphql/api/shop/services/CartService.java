package com.graphql.api.shop.services;

import com.graphql.api.shop.models.shop.Cart;

import java.util.List;

public interface CartService {
   
}
