<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Обработка отправленной формы для обновления товара
    $id = $_GET["id"];
    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];

    // Подключение к базе данных
    $conn = new mysqli("db", "user", "password", "appDB");

    if ($conn->connect_error) {
        die("Ошибка подключения к базе данных: " . $conn->connect_error);
    }

    // SQL-запрос для обновления записи
    $sql = "UPDATE products SET name='$name', description='$description', price='$price' WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        // Перенаправление на страницу чтения товара после успешной вставки
        header("Location: read.php");
        exit;
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    // Получение ID товара из запроса
    $id = $_GET["id"];

    // Подключение к базе данных
    $conn = new mysqli("db", "user", "password", "appDB");

    if ($conn->connect_error) {
        die("Ошибка подключения к базе данных: " . $conn->connect_error);
    }

    // SQL-запрос для выборки товара по ID
    $sql = "SELECT id, name, description, price FROM products WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row["name"];
        $description = $row["description"];
        $price = $row["price"];
    } else {
        echo "Товар не найден.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Обновить товар</title>
</head>
<body>
    <h2>Обновить товар</h2>
    <form method="get">
        ID: <input type="text" name="id" value="<?php echo $id; ?>"><br>
        <input type="submit" value="Найти">
    </form>
    <form method="post">
        Название: <input type="text" name="name" value="<?php echo $name; ?>"><br>
        Описание: <textarea name="description"><?php echo $description; ?></textarea><br>
        Цена: <input type="text" name="price" value="<?php echo $price; ?>"><br>
        <input type="submit" value="Обновить">
    </form>
</body>
</html>