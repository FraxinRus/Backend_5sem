<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Обработка отправленной формы для создания товара
    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    
    // Подключение к базе данных
    $conn = new mysqli("db", "user", "password", "appDB");

    if ($conn->connect_error) {
        die("Ошибка подключения к базе данных: " . $conn->connect_error);
    }

    // SQL-запрос для создания записи
    $sql = "INSERT INTO products (name, description, price) VALUES ('$name', '$description', '$price')";

    if ($conn->query($sql) === TRUE) {
        // Перенаправление на страницу чтения товара после успешной вставки
        header("Location: read.php");
        exit;
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Создать товар</title>
</head>
<body>
    <h2>Создать товар</h2>
    <form method="post">
        Название: <input type="text" name="name"><br>
        Описание: <textarea name="description"></textarea><br>
        Цена: <input type="text" name="price"><br>
        <input type="submit" value="Создать">
    </form>
</body>
</html>